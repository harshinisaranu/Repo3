import React from 'react';
const Property=({data,propertyDetails})=>{
    return (
        <div style={{width: 450 + 'px',borderRadius:15+'px', height:400 +'px',alignItems:'center'}} >
            <img src={`./${data.image}.png`} className="card-img-top" alt=".." />
            <table>
            <tr>
            <h5>{data.title}</h5></tr>
            <tr><h6><b>Location:</b>{data.city}</h6></tr>
            <tr><h6><b>Description:</b>{data.description}</h6></tr>
            <tr><h6><b>Available:</b>{data.availability}</h6></tr>
            <tr><h6><b>Nighty Fee:</b>{data.nightlyFee}</h6></tr>
            <tr><h6><b>Cleaning Fee:</b>{data.cleaningFee}</h6></tr>
            <tr><h6><b>Service Fee:</b>{data.serviceFee}</h6></tr>
            <tr><h6><b>Amenities:</b>{data.amenities}</h6></tr>
            <tr><h6><b>Bedrooms:</b>{data.bedrooms}</h6></tr>
            </table>
            <button type="button" className="btn btn-secondary" onClick={()=>{propertyDetails(false)}}>Close</button>
        </div>
    )

}
export default Property