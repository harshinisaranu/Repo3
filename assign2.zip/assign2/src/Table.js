import React from 'react';
const Table=({data,propertyDetails,showPropertyDetail})=>{
    return (
<table>
  
<div className="row row-cols-3 "style={{marginTop: 10+'px', marginRight: 20 +'px'}}>
                {data.map((item)=>(
                    <div className="col">
                    <div className="card" onClick={()=>{propertyDetails(true);showPropertyDetail(item)}} style={{width: 400 + 'px',borderRadius:15+'px',height:300 +'px'}}>
                      <img src={`./${item.image}.png`} className="card-img-top" alt=".." />
                      <div className="card-body">
                        <h5 className="card-title">{item.title}</h5>
                        <h6 className="card-text">{item.availability}</h6>
                      </div>
                    </div>
                  </div>
                ))
                }
            </div>
</table>

    )

}
export default Table 