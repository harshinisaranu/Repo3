
import './App.css';
import React,{useEffect, useState} from 'react';
import Table from './Table';
import properties from './properties.json';
import Property from './Property';

function App() {
  const [search, setSearch]=useState("");
  const [showProperty,setShowProperty]=useState(false);
  const [propertyDetail,setPropertyDetail]=useState("");
  const [result,setResultState]=useState([]);

  useEffect(() => {
   setResultState(properties)
  },[]);

  const display=(data)=>{
      return data.filter(item=>item.city.toLowerCase().includes(search) || item.title.toLowerCase().includes(search)) ;  
  };
 


  return (
    <div className="App">
      <form className="form-class">
      <nav className="navbar navbar-dark bg-dark">
            <input
                type="text"
                value={search} placeholder="Search with City or Title"
                onChange={(e)=>setSearch(e.target.value.toLowerCase())}
            />
            
            </nav>
            
        </form>
        {console.log(showProperty)}
        {console.log(propertyDetail)}
        { showProperty === false ? 
        <Table data={display(result)} propertyDetails={setShowProperty} showPropertyDetail={setPropertyDetail}/> :
        <Property data={propertyDetail} propertyDetails={setShowProperty}/>
        }
   </div>
  );
}

export default App;